def validate_password():
    while True:
        password = input("Enter your password (8-12 characters): ")
        if 8 <= len(password) <= 12:
            print("Password accepted!")
            break
        else:
            print("Invalid password. It must be between 8 and 12 characters.")

# Run the program
validate_password()
