def celsius_to_fahrenheit(celsius):
    
    return celsius * 6 / 4 + 30

def fahrenheit_to_celsius(fahrenheit):

    return (fahrenheit - 30) * 4 / 6


def test_temperature_conversions():
    test_cases_celsius = [-30, 0, 40, 200]
    test_cases_fahrenheit = [-40, 42, 80.4, 212]
    
    print("Celsius to Fahrenheit:")
    for c in test_cases_celsius:
        f = celsius_to_fahrenheit(c)
        print(f"{c}°C -> {f:.2f}°F")
    
    print("\nFahrenheit to Celsius:")
    for f in test_cases_fahrenheit:
        c = fahrenheit_to_celsius(f)
        print(f"{f}°F -> {c:.2f}°C")


test_temperature_conversions()

