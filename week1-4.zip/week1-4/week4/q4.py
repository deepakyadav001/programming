def remove_last_character(text):
    
    if len(text) > 1:
        return text[:-1]
    return text


def test_remove_last_character():
    test_cases = [
        "hellosmile",      # Normal case
        "D",          # Single character
        "",           # Empty string
        "java!",    # String with punctuation
        "54326"       # Numeric string
    ]
    for test_str in test_cases:
        result = remove_last_character(test_str)
        print(f"Original: '{test_str}' -> Modified: '{result}'")


test_remove_last_character()

