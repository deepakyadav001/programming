def simulate_password_choice():
    
    password = input("Enter a new password: ")
   
    confirm_password = input("Confirm your password: ")

   
    if password == confirm_password:
        print("Password Set Successfully!")
    else:
        print("Error: Passwords do not match. Please try again.")


simulate_password_choice()
